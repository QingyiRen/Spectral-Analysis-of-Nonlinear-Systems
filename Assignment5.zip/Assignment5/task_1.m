function y=task_1(x,d)
y=[];
for k=0:d
    for i=0:d-k
        y=[y;(x(1)^k)*(x(2)^i)];
    end
end
end