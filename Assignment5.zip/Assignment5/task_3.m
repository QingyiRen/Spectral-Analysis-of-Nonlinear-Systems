function [A,Y,Yp]=task_3(K,d,tau)
X= 2.*rand([2,K])-ones(2,K);
Xp=task_2(X,tau);
Y=[];
for i=1:K
Y=[Y task_1(X(:,i),d)];
end
Yp=[];
for i=1:K
Yp=[Yp task_1(Xp(:,i),d)];
end
A=lsqminnorm(Y',Yp');
A=A';
end