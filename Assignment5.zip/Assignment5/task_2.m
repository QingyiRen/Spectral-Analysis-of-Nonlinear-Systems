function Xp=task_2(X,tau)

function dxdt = vdp1(t,x)

dxdt = [-3/4*x(1)-1/8*x(2)+1/4*x(1)*x(2)-1/4*x(2)^2-1/2*x(1)^3; -1/8*x(1)-x(2)];
end
Xp=[];
for k=1:size(X,2)
[t,x] = ode45(@vdp1,[0,tau],X(:,k));
Xp=[Xp x(size(x,1),:)'];
end
end