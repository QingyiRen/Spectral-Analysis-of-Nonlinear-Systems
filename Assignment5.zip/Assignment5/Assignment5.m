clear;
clc;
close all;

addpath('C:\Users\linxi\Documents\MATLAB\chebfun-master\chebfun-master');
addpath('D:\eigtool-master\eigtool-master');

%% Task 1


a=2;
lambda=-1;
u=1;
[phi,dphi]=task1(a,lambda,u);
phi
dphi


%% Task 2


[gamma,delta]=recover(a,lambda,u);
gamma
delta


%% Task 3


a_new=15;
k=-4:0.01:-0.01;
iter=size(k,2);
lamda1=-k.*k;
u1=chebfun(@(z) 2.4*(sech(z))^2,[-a_new,a_new]);
rho=[];
for i=1:iter
 [ga,del]=recover(a_new,lamda1(i),u1);
 rho=[rho del/ga];
end
figure()
plot(k,real(rho));
hold on;
plot(k,imag(rho));
title('Real and Imaginary values of \rho')
xlabel('k');
ylabel('Value');
legend('Real value','Imaginary value')


%% Task 4
K=1000;
d=25;
tau=0.001;
[A,Y,Yp]=task_3(K,d,tau);
[V,D]=eig(A');
eigA=diag(D);
lamda=log(eigA)/tau;

figure()
scatter(real(lamda),imag(lamda));
% From the figure we can see the eigenvalues whose real part >-5.5 lie at
% -5,-4,-3,-2,-1,0.

la1=-0.698;
la2=-1.052;
% eg1=exp(tau*la1);% lamda 1=−0.698
% eg2=exp(tau*la2);% lamda 2=−1.052
% eg1
% eg2
[eig1,lam1]=min(lamda-la1*ones(size(lamda)));
[eig2,lam2]=min(lamda-la2*ones(size(lamda)));

%Result of one test: 38th eigenvalue is 0.698, 39th eigenvalue is 1.052

%% task5

c1=V(:,lam1);
c2=V(:,lam2);
x=-1:0.02:1;
xt=[];
for i=1:length(x)
    for j=1:length(x)
        xt=[xt;x(i) x(j)];
    end
end
gx=[]; 
for i=1:length(xt)
    gx=[gx task_1(xt(i,:)',d)];
end

psi1=c1'*gx;
psi2=c2'*gx;

[X,Y]=meshgrid(x,x);
Z1=reshape(psi1,101,101);
Z2=reshape(psi2,101,101);
figure()
contour(X,Y,Z1,'ShowText','on');
title('contour plot of eigenfunction \psi_1(x)')
figure()
contour(X,Y,Z2,'ShowText','on');
title('contour plot of eigenfunction \psi_2(x)')


%% Functions

function [phi,dphi]=task1(a,lambda,u)
N = chebop(-a, a);
N.op = @(t,phi) diff(phi,2)-(lambda-u)*phi;
N.lbc = [exp(sqrt(lambda)*(-a));sqrt(lambda)*exp(sqrt(lambda)*(-a))];
phi=N\0;
dphi=diff(phi);
phi=phi.pointValues(2);
dphi=dphi.pointValues(2);
end

function [gamma,delta]=recover(a,lambda,u)
  [phi,dphi]=task1(a,lambda,u);
  A=[exp(sqrt(lambda)*a) exp(-sqrt(lambda)*a);sqrt(lambda)*exp(sqrt(lambda)*a) -sqrt(lambda)*exp(-sqrt(lambda)*a)];
  y=inv(A)*[phi;dphi];
  gamma=y(1);
  delta=y(2);
end
