K=10;

d=1;
tau=1;
X= 2.*rand([2,K])-ones(2,K);
Y=[];
for i=1:K
Y=[Y task_1(X(:,i),d)];
end
Yp=task_2(Y,tau);
A=lsqminnorm(Y',Yp');